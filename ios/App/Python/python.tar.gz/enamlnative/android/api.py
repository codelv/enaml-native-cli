
from .android_location import LocationManager, Location