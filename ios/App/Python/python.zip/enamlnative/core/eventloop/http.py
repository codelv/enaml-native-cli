
#: TODO, check platform somehow
from ..android.http import AsyncHttpClient